﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorldConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Задание 1
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Задание №1");                       

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("\nВедите целое число: ");

                if (int.TryParse(Console.ReadLine(), out int integer))
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    if (integer % 2 == 1)
                        Console.WriteLine("Не чётное число");
                    else
                        Console.WriteLine("Чётное число");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Вы ввели не целое число! Повторите попытку!");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
        }
    }
}
