﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorldConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Задание 2
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Задание №2");
            int nominal = 0, sum = 0;
            
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("\nСколько карт у вас на руках?");

                // Проверяем коорекность ввода целого числа
                if (int.TryParse(Console.ReadLine(), out int celoeChislo))
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Требуется поочередно ввести номиналы карт.");
                    Console.WriteLine("Допустимые значения: 2, 3, 4, 5, 6, 7, 8, 9, 10, Валет = J, Дама = Q, Король = K, Туз = T.");
                    Console.ForegroundColor = ConsoleColor.White;

                    for (int i = 0; i < celoeChislo; i++)
                    {
                        while (true)
                        {
                            Console.Write($"Введите карту номер {i + 1}: ");
                            string typeOfCard = Console.ReadLine();

                            // Если цифра - то не преобразуем в число
                            if (int.TryParse(typeOfCard, out int numericCard) && 1 < numericCard && numericCard < 11)
                            {
                                nominal = numericCard;
                                break;
                            }
                            // Если буква - то преобразуем в число
                            else if (char.TryParse(typeOfCard, out char charCard) &&
                                (char.ToUpper(charCard) == Convert.ToChar("J") ||
                                 char.ToUpper(charCard) == Convert.ToChar("Q") ||
                                 char.ToUpper(charCard) == Convert.ToChar("K") ||
                                 char.ToUpper(charCard) == Convert.ToChar("T")))
                            {
                                nominal = 10;
                                break;
                            }
                            // Если не допустимое значение - сообщение
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Недопустимое значение! Повторите попытку!");
                                Console.ForegroundColor = ConsoleColor.White;
                            }                            
                        }
                        sum += nominal;
                    }                   
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine($"Сумма карт: {sum}");                    
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Вы ввели не целое число! Повторите попытку!");
                    Console.ForegroundColor = ConsoleColor.White;
                }                
            }

        }
    }
}
