﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorldConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Задание 3
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Задание №3");
            bool isSimple = true;

            while (true)
            {
                isSimple = true;

                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("\nВведите целое число: ");

                // Проверяем коорекность ввода целого числа
                if (int.TryParse(Console.ReadLine(), out int integer))
                {
                    for (int i = 2; i < integer - 1; i++)
                    {
                        if (integer % i == 0)
                        {                            
                            isSimple = false;
                            break;
                        }
                    }
                    if (isSimple)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine($"Простое число.");
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine($"Не простое число: найден общий делитель.");
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Вы ввели не целое число! Повторите попытку!");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }

        }
    }
}
